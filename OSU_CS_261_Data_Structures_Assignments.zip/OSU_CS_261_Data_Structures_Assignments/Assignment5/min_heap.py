# Name: [Your Name]
# OSU Email: [Your Email]
# Course: CS261 - Data Structures
# Assignment: 5
# Due Date: Nov 25, 2025
# Description: Implementation of MinHeap data structure with array-based representation


from dynamic_array import *


class MinHeapException(Exception):
    """
    Custom exception to be used by MinHeap class
    DO NOT CHANGE THIS CLASS IN ANY WAY
    """
    pass


class MinHeap:
    def __init__(self, start_heap=None):
        """
        Initialize a new MinHeap
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        self._heap = DynamicArray()

        # populate MinHeap with initial values (if provided)
        # before using this feature, implement add() method
        if start_heap:
            for node in start_heap:
                self.add(node)

    def __str__(self) -> str:
        """
        Return MinHeap content in human-readable form
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        heap_data = [self._heap[i] for i in range(self._heap.length())]
        return "HEAP " + str(heap_data)

    def add(self, node: object) -> None:
        """
        Adds a new object to the MinHeap maintaining heap property
        Runtime complexity: O(log n)
        """
        # Add the new node at the end
        self._heap.append(node)
        
        # Percolate up to maintain heap property
        current_index = self._heap.length() - 1
        
        while current_index > 0:
            parent_index = (current_index - 1) // 2
            
            # If current node is less than parent, swap
            if self._heap[current_index] < self._heap[parent_index]:
                # Swap
                temp = self._heap[current_index]
                self._heap[current_index] = self._heap[parent_index]
                self._heap[parent_index] = temp
                
                # Move up to parent position
                current_index = parent_index
            else:
                # Heap property satisfied
                break

    def is_empty(self) -> bool:
        """
        Returns True if the heap is empty, False otherwise
        Runtime complexity: O(1)
        """
        return self._heap.length() == 0

    def get_min(self) -> object:
        """
        Returns the minimum key (root) without removing it
        Raises MinHeapException if heap is empty
        Runtime complexity: O(1)
        """
        if self.is_empty():
            raise MinHeapException
        
        return self._heap[0]

    def remove_min(self) -> object:
        """
        Returns and removes the minimum key (root)
        Raises MinHeapException if heap is empty
        Runtime complexity: O(log n)
        """
        if self.is_empty():
            raise MinHeapException
        
        # Save the minimum value to return
        min_value = self._heap[0]
        
        # Replace root with last element
        last_index = self._heap.length() - 1
        self._heap[0] = self._heap[last_index]
        
        # Remove the last element (using remove_at_index would trigger capacity reduction)
        # We'll just manually decrease size
        # Actually, we need to be careful here - let's use a proper approach
        
        # If only one element, just clear it
        if self._heap.length() == 1:
            self._heap = DynamicArray()
        else:
            # Replace root with last, then remove last
            self._heap[0] = self._heap[last_index]
            self._heap.remove_at_index(last_index)
            
            # Percolate down from root
            self._percolate_down(0)
        
        return min_value
    
    def _percolate_down(self, parent_index: int) -> None:
        """
        Helper method to percolate down from a given index
        """
        size = self._heap.length()
        
        while True:
            left_index = 2 * parent_index + 1
            right_index = 2 * parent_index + 2
            smallest_index = parent_index
            
            # Check if left child exists and is smaller
            if left_index < size and self._heap[left_index] < self._heap[smallest_index]:
                smallest_index = left_index
            
            # Check if right child exists and is smaller
            if right_index < size and self._heap[right_index] < self._heap[smallest_index]:
                smallest_index = right_index
            
            # If parent is smallest, we're done
            if smallest_index == parent_index:
                break
            
            # Swap parent with smallest child
            temp = self._heap[parent_index]
            self._heap[parent_index] = self._heap[smallest_index]
            self._heap[smallest_index] = temp
            
            # Move down to the child's position
            parent_index = smallest_index

    def build_heap(self, da: DynamicArray) -> None:
        """
        Builds a proper MinHeap from a DynamicArray
        Runtime complexity: O(n)
        """
        # Create a new DynamicArray and copy elements
        self._heap = DynamicArray()
        for i in range(da.length()):
            self._heap.append(da[i])
        
        # Start from the last non-leaf node and percolate down
        # Last non-leaf is at index (n-2)//2
        size = self._heap.length()
        if size <= 1:
            return
        
        # Heapify from last non-leaf to root
        start_index = (size - 2) // 2
        for i in range(start_index, -1, -1):
            self._percolate_down(i)

    def size(self) -> int:
        """
        Returns the number of elements in the heap
        Runtime complexity: O(1)
        """
        return self._heap.length()

    def clear(self) -> None:
        """
        Clears the contents of the heap
        Runtime complexity: O(1)
        """
        self._heap = DynamicArray()


def heapsort(da: DynamicArray) -> None:
    """
    Sorts the DynamicArray in place using heapsort (non-ascending/descending order)
    Runtime complexity: O(n log n)
    """
    size = da.length()
    if size <= 1:
        return
    
    # Step 1: Build a MIN heap (for descending order)
    # Start from last non-leaf and heapify
    start_index = (size - 2) // 2
    for i in range(start_index, -1, -1):
        _percolate_down(da, i, size)
    
    # Step 2: Extract elements one by one
    for end in range(size - 1, 0, -1):
        # Move current root (min) to end
        temp = da[0]
        da[0] = da[end]
        da[end] = temp
        
        # Heapify the reduced heap
        _percolate_down(da, 0, end)


# It's highly recommended that you implement the following optional          #
# helper function for percolating elements down the MinHeap. You can call    #
# this from inside the MinHeap class. You may edit the function definition.  #

def _percolate_down(da: DynamicArray, parent: int, size: int = None) -> None:
    """
    Percolates element at parent index down the heap
    For heapsort, this creates a MIN heap (to get descending order)
    If size is None, uses the full array length
    """
    if size is None:
        size = da.length()
    
    while True:
        left = 2 * parent + 1
        right = 2 * parent + 2
        smallest = parent
        
        # For heapsort (MIN heap), find smallest among parent and children
        if left < size and da[left] < da[smallest]:
            smallest = left
        
        if right < size and da[right] < da[smallest]:
            smallest = right
        
        # If parent is smallest, we're done
        if smallest == parent:
            break
        
        # Swap with smallest child
        temp = da[parent]
        da[parent] = da[smallest]
        da[smallest] = temp
        
        # Continue from child position
        parent = smallest


# ------------------- BASIC TESTING -----------------------------------------


if __name__ == '__main__':

    print("\nPDF - add example 1")
    print("-------------------")
    h = MinHeap()
    print(h, h.is_empty())
    for value in range(300, 200, -15):
        h.add(value)
        print(h)

    print("\nPDF - add example 2")
    print("-------------------")
    h = MinHeap(['fish', 'bird'])
    print(h)
    for value in ['monkey', 'zebra', 'elephant', 'horse', 'bear']:
        h.add(value)
        print(h)

    print("\nPDF - is_empty example 1")
    print("-------------------")
    h = MinHeap([2, 4, 12, 56, 8, 34, 67])
    print(h.is_empty())

    print("\nPDF - is_empty example 2")
    print("-------------------")
    h = MinHeap()
    print(h.is_empty())

    print("\nPDF - get_min example 1")
    print("-----------------------")
    h = MinHeap(['fish', 'bird'])
    print(h)
    print(h.get_min(), h.get_min())

    print("\nPDF - remove_min example 1")
    print("--------------------------")
    h = MinHeap([1, 10, 2, 9, 3, 8, 4, 7, 5, 6])
    while not h.is_empty() and h.is_empty() is not None:
        print(h, end=' ')
        print(h.remove_min())

    print("\nPDF - build_heap example 1")
    print("--------------------------")
    da = DynamicArray([100, 20, 6, 200, 90, 150, 300])
    h = MinHeap(['zebra', 'apple'])
    print(h)
    h.build_heap(da)
    print(h)

    print("--------------------------")
    print("Inserting 500 into input DA:")
    da[0] = 500
    print(da)

    print("Your MinHeap:")
    print(h)
    if h.get_min() == 500:
        print("Error: input array and heap's underlying DA reference the same object in memory")

    print("\nPDF - size example 1")
    print("--------------------")
    h = MinHeap([100, 20, 6, 200, 90, 150, 300])
    print(h.size())

    print("\nPDF - size example 2")
    print("--------------------")
    h = MinHeap([])
    print(h.size())

    print("\nPDF - clear example 1")
    print("---------------------")
    h = MinHeap(['monkey', 'zebra', 'elephant', 'horse', 'bear'])
    print(h)
    print(h.clear())
    print(h)

    print("\nPDF - heapsort example 1")
    print("------------------------")
    da = DynamicArray([100, 20, 6, 200, 90, 150, 300])
    print(f"Before: {da}")
    heapsort(da)
    print(f"After:  {da}")

    print("\nPDF - heapsort example 2")
    print("------------------------")
    da = DynamicArray(['monkey', 'zebra', 'elephant', 'horse', 'bear'])
    print(f"Before: {da}")
    heapsort(da)
    print(f"After:  {da}")
# Name: Melissa Campbell    
# OSU Email: Campmeli@oregonstate.edu
# Course: CS261 - Data Structures
# Assignment: assignment 4
# Due Date: 11/4
# Description: AVL Tree implementation that extends BST with self-balancing
# functionality. Includes rotation methods to maintain tree balance after
# insertions and deletions.


import random
from queue_and_stack import Queue, Stack
from bst import BSTNode, BST


class AVLNode(BSTNode):
    """
    AVL Tree Node class. Inherits from BSTNode
    DO NOT CHANGE THIS CLASS IN ANY WAY
    """

    def __init__(self, value: object) -> None:
        """
        Initialize a new AVL node
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        # call __init__() from parent class
        super().__init__(value)

        # new variables needed for AVL
        self.parent = None
        self.height = 0

    def __str__(self) -> str:
        """
        Override string method
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return 'AVL Node: {}'.format(self.value)


class AVL(BST):
    """AVL Tree class. Inherits from BST"""

    def __init__(self, start_tree=None) -> None:
        """
        Initialize a new AVL Tree
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        # call __init__() from parent class
        super().__init__(start_tree)

    def __str__(self) -> str:
        """
        Override string method; display in pre-order
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        values = []
        super()._str_helper(self._root, values)
        return "AVL pre-order { " + ", ".join(values) + " }"

    def is_valid_avl(self) -> bool:
        """
        Perform pre-order traversal of the tree. Return False if there
        are any problems with attributes of any of the nodes in the tree.

        This is intended to be a troubleshooting 'helper' method to help
        find any inconsistencies in the tree after the add() or remove()
        operations. Review the code to understand what this method is
        checking and how it determines whether the AVL tree is correct.

        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        stack = Stack()
        stack.push(self._root)
        while not stack.is_empty():
            node = stack.pop()
            if node:
                # check for correct height (relative to children)
                left = node.left.height if node.left else -1
                right = node.right.height if node.right else -1
                if node.height != 1 + max(left, right):
                    return False

                if node.parent:
                    # parent and child pointers are in sync
                    if node.value < node.parent.value:
                        check_node = node.parent.left
                    else:
                        check_node = node.parent.right
                    if check_node != node:
                        return False
                else:
                    # NULL parent is only allowed on the root of the tree
                    if node != self._root:
                        return False
                stack.push(node.right)
                stack.push(node.left)
        return True

    # ---------------------------------------------------------------------- #

    def add(self, value: object) -> None:
        """
        Add a value to the AVL tree.
        After insertion, rebalance from insertion point to root.
        Duplicates are not added.
        """
        # Create new node
        new_node = AVLNode(value)
        
        # If tree is empty
        if self._root is None:
            self._root = new_node
            return
        
        # Find insertion position (skip if duplicate found)
        parent = None
        current = self._root
        
        while current is not None:
            parent = current
            if value < current.value:
                current = current.left
            elif value > current.value:
                current = current.right
            else:
                # Duplicate found - do not add
                return
        
        # Insert the node
        new_node.parent = parent
        if value < parent.value:
            parent.left = new_node
        else:
            parent.right = new_node
        
        # Rebalance from insertion point up to root
        current = parent
        while current is not None:
            # Save parent before rebalancing
            parent_node = current.parent
            
            # Rebalance current node (rotation handles parent pointers internally)
            new_subtree_root = self._rebalance(current)
            
            # Only update parent's child pointer to new root
            # DON'T touch new_subtree_root.parent - rotation already set it
            if parent_node is None:
                self._root = new_subtree_root
            elif parent_node.left == current:
                parent_node.left = new_subtree_root
            else:
                parent_node.right = new_subtree_root
            
            # Move up using the new root's parent
            current = parent_node

    def remove(self, value: object) -> bool:
        """
        Remove a value from the AVL tree.
        After removal, rebalance from removal point to root.
        """
        # Find node to remove and track path
        path = []
        parent = None
        current = self._root
        
        while current is not None and current.value != value:
            path.append(current)
            parent = current
            if value < current.value:
                current = current.left
            else:
                current = current.right
        
        # Not found
        if current is None:
            return False
        
        # Node with two children
        if current.left and current.right:
            # Find successor
            path.append(current)
            successor_parent = current
            successor = current.right
            
            while successor.left:
                path.append(successor)
                successor_parent = successor
                successor = successor.left
            
            # Copy value
            current.value = successor.value
            
            # Remove successor
            if successor_parent.left == successor:
                successor_parent.left = successor.right
            else:
                successor_parent.right = successor.right
                
            if successor.right:
                successor.right.parent = successor_parent
                
        # Node with 0 or 1 child
        else:
            child = current.left if current.left else current.right
            
            if parent is None:
                self._root = child
            elif parent.left == current:
                parent.left = child
            else:
                parent.right = child
                
            if child:
                child.parent = parent
        
        # Rebalance up the path
        for node in reversed(path):
            p = node.parent
            new_root = self._rebalance(node)
            
            if p is None:
                self._root = new_root
            elif p.left == node:
                p.left = new_root
            else:
                p.right = new_root
        
        return True

    # Experiment and see if you can use the optional                         #
    # subtree removal methods defined in the BST here in the AVL.            #
    # Call normally using self -> self._remove_no_subtrees(parent, node)     #
    # You need to override the _remove_two_subtrees() method in any case.    #
    # Remove these comments.                                                 #
    # Remove these method stubs if you decide not to use them.               #
    # Change this method in any way you'd like.                              #

    def _remove_two_subtrees(self, remove_parent: AVLNode, remove_node: AVLNode) -> AVLNode:
        """
        Remove a node with two children in AVL tree.
        Find inorder successor, swap values, then remove successor.
        Return the parent of the physically removed node (for rebalancing).
        """
        # Find inorder successor
        successor_parent = remove_node
        successor = remove_node.right
        
        while successor.left is not None:
            successor_parent = successor
            successor = successor.left
        
        # Swap values
        remove_node.value = successor.value
        
        # Remove successor (has at most right child)
        if successor_parent == remove_node:
            successor_parent.right = successor.right
        else:
            successor_parent.left = successor.right
        
        # Update parent pointer if successor had a right child
        if successor.right:
            successor.right.parent = successor_parent
        
        return successor_parent

    # It's highly recommended to implement                          #
    # the following methods for balancing the AVL Tree.             #
    # Remove these comments.                                        #
    # Remove these method stubs if you decide not to use them.      #
    # Change these methods in any way you'd like.                   #

    def _balance_factor(self, node: AVLNode) -> int:
        """
        Calculate balance factor of a node.
        Balance Factor = height(right subtree) - height(left subtree)
        """
        if node is None:
            return 0
        
        right_height = self._get_height(node.right)
        left_height = self._get_height(node.left)
        return right_height - left_height

    def _get_height(self, node: AVLNode) -> int:
        """
        Get the height of a node.
        Return -1 if node is None (for balance factor calculation).
        """
        if node is None:
            return -1
        return node.height

    def _rotate_left(self, node: AVLNode) -> AVLNode:
        """
        Perform left rotation around node.
        Returns the new root of this subtree (C).
        """
        # Save the right child (will become new root)
        C = node.right
        
        # Update parent pointers
        C.parent = node.parent
        node.parent = C
        
        # Rotate: C's left child becomes N's right child
        node.right = C.left
        if node.right:
            node.right.parent = node
        
        # Complete rotation: N becomes C's left child
        C.left = node
        
        # Update heights (update lower node first)
        self._update_height(node)
        self._update_height(C)
        
        return C

    def _rotate_right(self, node: AVLNode) -> AVLNode:
        """
        Perform right rotation around node.
        Returns the new root of this subtree (C).
        """
        # Save the left child (will become new root)
        C = node.left
        
        # Update parent pointers
        C.parent = node.parent
        node.parent = C
        
        # Rotate: C's right child becomes N's left child
        node.left = C.right
        if node.left:
            node.left.parent = node
        
        # Complete rotation: N becomes C's right child
        C.right = node
        
        # Update heights (update lower node first)
        self._update_height(node)
        self._update_height(C)
        
        return C

    def _update_height(self, node: AVLNode) -> None:
        """
        Update the height of a node based on its children.
        Height = 1 + max(left_height, right_height)
        """
        if node is None:
            return
        
        left_height = self._get_height(node.left)
        right_height = self._get_height(node.right)
        node.height = 1 + max(left_height, right_height)

    def _rebalance(self, node: AVLNode) -> AVLNode:
        """
        Rebalance the tree at node if needed.
        Returns the new root of this subtree.
        """
        # Update height first
        self._update_height(node)
        
        # Check balance factor
        bf = self._balance_factor(node)
        
        # Left-heavy (balance factor is -2)
        if bf == -2:
            # Check left child's balance factor
            if self._balance_factor(node.left) <= 0:
                # L-L case: single right rotation
                node = self._rotate_right(node)
            else:
                # L-R case: double rotation (left then right)
                node.left = self._rotate_left(node.left)
                node = self._rotate_right(node)
        
        # Right-heavy (balance factor is 2)
        elif bf == 2:
            # Check right child's balance factor
            if self._balance_factor(node.right) >= 0:
                # R-R case: single left rotation
                node = self._rotate_left(node)
            else:
                # R-L case: double rotation (right then left)
                node.right = self._rotate_right(node.right)
                node = self._rotate_left(node)
        
        return node


# ------------------- BASIC TESTING -----------------------------------------


if __name__ == '__main__':

    print("\nPDF - method add() example 1")
    print("----------------------------")
    test_cases = (
        (1, 2, 3),  # RR
        (3, 2, 1),  # LL
        (1, 3, 2),  # RL
        (3, 1, 2),  # LR
    )
    for case in test_cases:
        tree = AVL(case)
        print(tree)
        tree.print_tree()

    print("\nPDF - method add() example 2")
    print("----------------------------")
    test_cases = (
        (10, 20, 30, 40, 50),   # RR, RR
        (10, 20, 30, 50, 40),   # RR, RL
        (30, 20, 10, 5, 1),     # LL, LL
        (30, 20, 10, 1, 5),     # LL, LR
        (5, 4, 6, 3, 7, 2, 8),  # LL, RR
        (range(0, 30, 3)),
        (range(0, 31, 3)),
        (range(0, 34, 3)),
        (range(10, -10, -2)),
        ('A', 'B', 'C', 'D', 'E'),
        (1, 1, 1, 1),
    )
    for case in test_cases:
        tree = AVL(case)
        print('INPUT  :', case)
        print('RESULT :', tree)

    print("\nPDF - method add() example 3")
    print("----------------------------")
    for _ in range(100):
        case = list(set(random.randrange(1, 20000) for _ in range(900)))
        tree = AVL()
        for value in case:
            tree.add(value)
        if not tree.is_valid_avl():
            raise Exception("PROBLEM WITH ADD OPERATION")
    print('add() stress test finished')

    print("\nPDF - method remove() example 1")
    print("-------------------------------")
    test_cases = (
        ((1, 2, 3), 1),  # no AVL rotation
        ((1, 2, 3), 2),  # no AVL rotation
        ((1, 2, 3), 3),  # no AVL rotation
        ((50, 40, 60, 30, 70, 20, 80, 45), 0),
        ((50, 40, 60, 30, 70, 20, 80, 45), 45),  # no AVL rotation
        ((50, 40, 60, 30, 70, 20, 80, 45), 40),  # no AVL rotation
        ((50, 40, 60, 30, 70, 20, 80, 45), 30),  # no AVL rotation
    )
    for case, del_value in test_cases:
        tree = AVL(case)
        print('INPUT  :', tree, 'DEL:', del_value)
        tree.remove(del_value)
        print('RESULT :', tree)

    print("\nPDF - method remove() example 2")
    print("-------------------------------")
    test_cases = (
        ((50, 40, 60, 30, 70, 20, 80, 45), 20),  # RR
        ((50, 40, 60, 30, 70, 20, 80, 15), 40),  # LL
        ((50, 40, 60, 30, 70, 20, 80, 35), 20),  # RL
        ((50, 40, 60, 30, 70, 20, 80, 25), 40),  # LR
    )
    for case, del_value in test_cases:
        tree = AVL(case)
        print('INPUT  :', tree, 'DEL:', del_value)
        tree.print_tree()
        tree.remove(del_value)
        print('RESULT :', tree)
        tree.print_tree()
        print('')

    print("\nPDF - method remove() example 3")
    print("-------------------------------")
    case = range(-9, 16, 2)
    tree = AVL(case)
    for del_value in case:
        print('INPUT  :', tree, del_value)
        tree.remove(del_value)
        print('RESULT :', tree)

    print("\nPDF - method remove() example 4")
    print("-------------------------------")
    case = range(0, 34, 3)
    tree = AVL(case)
    for _ in case[:-2]:
        root_value = tree.get_root().value
        print('INPUT  :', tree, root_value)
        tree.remove(root_value)
        print('RESULT :', tree)

    print("\nPDF - method remove() example 5")
    print("-------------------------------")
    for _ in range(100):
        case = list(set(random.randrange(1, 20000) for _ in range(900)))
        tree = AVL(case)
        for value in case[::2]:
            tree.remove(value)
        if not tree.is_valid_avl():
            raise Exception("PROBLEM WITH REMOVE OPERATION")
    print('remove() stress test finished')

    print("\nPDF - method contains() example 1")
    print("---------------------------------")
    tree = AVL([10, 5, 15])
    print(tree.contains(15))
    print(tree.contains(-10))
    print(tree.contains(15))

    print("\nPDF - method contains() example 2")
    print("---------------------------------")
    tree = AVL()
    print(tree.contains(0))

    print("\nPDF - method inorder_traversal() example 1")
    print("---------------------------------")
    tree = AVL([10, 20, 5, 15, 17, 7, 12])
    print(tree.inorder_traversal())

    print("\nPDF - method inorder_traversal() example 2")
    print("---------------------------------")
    tree = AVL([8, 10, -4, 5, -1])
    print(tree.inorder_traversal())

    print("\nPDF - method find_min() example 1")
    print("---------------------------------")
    tree = AVL([10, 20, 5, 15, 17, 7, 12])
    print(tree)
    print("Minimum value is:", tree.find_min())

    print("\nPDF - method find_min() example 2")
    print("---------------------------------")
    tree = AVL([8, 10, -4, 5, -1])
    print(tree)
    print("Minimum value is:", tree.find_min())

    print("\nPDF - method find_max() example 1")
    print("---------------------------------")
    tree = AVL([10, 20, 5, 15, 17, 7, 12])
    print(tree)
    print("Maximum value is:", tree.find_max())

    print("\nPDF - method find_max() example 2")
    print("---------------------------------")
    tree = AVL([8, 10, -4, 5, -1])
    print(tree)
    print("Maximum value is:", tree.find_max())

    print("\nPDF - method is_empty() example 1")
    print("---------------------------------")
    tree = AVL([10, 20, 5, 15, 17, 7, 12])
    print("Tree is empty:", tree.is_empty())

    print("\nPDF - method is_empty() example 2")
    print("---------------------------------")
    tree = AVL()
    print("Tree is empty:", tree.is_empty())

    print("\nPDF - method make_empty() example 1")
    print("---------------------------------")
    tree = AVL([10, 20, 5, 15, 17, 7, 12])
    print("Tree before make_empty():", tree)
    tree.make_empty()
    print("Tree after make_empty(): ", tree)

    print("\nPDF - method make_empty() example 2")
    print("---------------------------------")
    tree = AVL()
    print("Tree before make_empty():", tree)
    tree.make_empty()
    print("Tree after make_empty(): ", tree)
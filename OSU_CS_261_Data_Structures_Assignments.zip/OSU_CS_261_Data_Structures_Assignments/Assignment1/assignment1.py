# Name: Melissa Campbell
# OSU Email: Campmeli@oregonstate.edu       
# Course: CS261 - Data Structures
# Assignment: 1 
# Due Date: Oct 31st
# Description: This assignment reviews basic Python programming concepts by implementing and testing several small functions that manipulate data stored in a StaticArray.
# The tasks include operations such as FizzBuzz, reversing arrays, rotating elements, generating numeric ranges, checking sort order, 
# finding modes, removing duplicates, counting sort, and sorting squared values. The goal is to practice algorithmic thinking, loops, 
# and array manipulation in preparation for more advanced data structure work.


import random
from static_array import *


# ------------------- PROBLEM 1 - MIN_MAX -----------------------------------


def min_max(arr: StaticArray) -> tuple[int, int]:
    """
    TODO: Write this implementation
    """
    mn = mx = arr[0]
    for i in range(1, arr.length()):
        x = arr[i]
        if x < mn: mn = x
        if x > mx: mx = x
    return (mn, mx)

    pass


# ------------------- PROBLEM 2 - FIZZ_BUZZ ---------------------------------
  
def fizz_buzz(arr: StaticArray) -> StaticArray:
    result = StaticArray(arr.length())
    for i in range(arr.length()):
        val = arr[i]
        if val % 3 == 0 and val % 5 == 0:
            result[i] = "fizzbuzz"
        elif val % 3 == 0:
            result[i] = "fizz"
        elif val % 5 == 0:
            result[i] = "buzz"
        else:
            result[i] = val
    return result

    pass


# ------------------- PROBLEM 3 - REVERSE -----------------------------------

def reverse(arr: StaticArray) -> None:
        left, right = 0, arr.length() - 1
        while left < right:
            arr[left], arr[right] = arr[right], arr[left]
            left += 1
            right -= 1

pass


# ------------------- PROBLEM 4 - ROTATE ------------------------------------


def rotate(arr: StaticArray, steps: int) -> StaticArray:
    n = arr.length()
    result = StaticArray(n)
    steps %= n
    for i in range(n):
        result[(i + steps) % n] = arr[i]
    return result

    pass


# ------------------- PROBLEM 5 - SA_RANGE ----------------------------------


def sa_range(start: int, end: int) -> StaticArray:
    size = abs(end - start) + 1
    result = StaticArray(size)
    step = 1 if start <= end else -1
    val = start
    for i in range(size):
        result[i] = val
        val += step
    return result

    pass


# ------------------- PROBLEM 6 - IS_SORTED ---------------------------------


def is_sorted(arr: StaticArray) -> int:
    n = arr.length()
    if n <= 1:
        return 1  # single element counts as strictly increasing

    inc = True
    dec = True

    for i in range(n - 1):
        a, b = arr[i], arr[i + 1]
        if not (a < b):
            inc = False
        if not (a > b):
            dec = False

    if inc:
        return 1
    if dec:
        return -1
    return 0

    pass


# ------------------- PROBLEM 7 - FIND_MODE -----------------------------------


def find_mode(arr: StaticArray) -> tuple[object, int]:
    mode, mode_count = arr[0], 1
    current_val, current_count = arr[0], 1
    for i in range(1, arr.length()):
        if arr[i] == current_val:
            current_count += 1
        else:
            if current_count > mode_count:
                mode, mode_count = current_val, current_count
            current_val = arr[i]
            current_count = 1
    if current_count > mode_count:
        mode, mode_count = current_val, current_count
    return mode, mode_count

    pass


# ------------------- PROBLEM 8 - REMOVE_DUPLICATES -------------------------


def remove_duplicates(arr: StaticArray) -> StaticArray:
    n = arr.length()
    if n == 0:
        return StaticArray(0)

    # count uniques first
    uniques = 1
    for i in range(1, n):
        if arr[i] != arr[i - 1]:
            uniques += 1

    # write uniques into result
    out = StaticArray(uniques)
    out_idx = 0
    out[out_idx] = arr[0]
    out_idx += 1
    for i in range(1, n):
        if arr[i] != arr[i - 1]:
            out[out_idx] = arr[i]
            out_idx += 1
    return out

    pass


# ------------------- PROBLEM 9 - COUNT_SORT --------------------------------


def count_sort(arr: StaticArray) -> StaticArray:
    n = arr.length()
    if n == 0:
        return StaticArray(0)

    # find min & max
    mn = mx = arr[0]
    for i in range(1, n):
        if arr[i] < mn:
            mn = arr[i]
        if arr[i] > mx:
            mx = arr[i]

    k = mx - mn + 1
    counts = StaticArray(k)
    for i in range(k):
        counts[i] = 0

    # count occurrences
    for i in range(n):
        idx = arr[i] - mn
        counts[idx] = counts[idx] + 1

    # write result in DESCENDING order
    out = StaticArray(n)
    pos = 0
    for v in range(k - 1, -1, -1):   # high → low
        freq = counts[v]
        while freq > 0:
            out[pos] = v + mn
            pos += 1
            freq -= 1
    return out

    pass


# ------------------- PROBLEM 10 - SORTED SQUARES ---------------------------


def sorted_squares(arr: StaticArray) -> StaticArray:
    n = arr.length()
    result = StaticArray(n)
    left, right, pos = 0, n - 1, n - 1
    while left <= right:
        left_sq = arr[left] ** 2
        right_sq = arr[right] ** 2
        if left_sq > right_sq:
            result[pos] = left_sq
            left += 1
        else:
            result[pos] = right_sq
            right -= 1
        pos -= 1
    return result

    pass


# ------------------- BASIC TESTING -----------------------------------------


if __name__ == "__main__":

    print('\n# min_max example 1')
    arr = StaticArray(5)
    for i, value in enumerate([7, 8, 6, -5, 4]):
        arr[i] = value
    print(arr)
    result = min_max(arr)
    if result:
        print(f"Min: {result[0]: 3}, Max: {result[1]}")
    else:
        print("min_max() not yet implemented")

    print('\n# min_max example 2')
    arr = StaticArray(1)
    arr[0] = 100
    print(arr)
    result = min_max(arr)
    if result:
        print(f"Min: {result[0]}, Max: {result[1]}")
    else:
        print("min_max() not yet implemented")

    print('\n# min_max example 3')
    test_cases = (
        [3, 3, 3],
        [-10, -30, -5, 0, -10],
        [25, 50, 0, 10],
    )
    for case in test_cases:
        arr = StaticArray(len(case))
        for i, value in enumerate(case):
            arr[i] = value
        print(arr)
        result = min_max(arr)
        if result:
            print(f"Min: {result[0]: 3}, Max: {result[1]}")
        else:
            print("min_max() not yet implemented")

    print('\n# fizz_buzz example 1')
    source = [_ for _ in range(-5, 20, 4)]
    arr = StaticArray(len(source))
    for i, value in enumerate(source):
        arr[i] = value
    print(fizz_buzz(arr))
    print(arr)

    print('\n# reverse example 1')
    source = [_ for _ in range(-20, 20, 7)]
    arr = StaticArray(len(source))
    for i, value in enumerate(source):
        arr.set(i, value)
    print(arr)
    reverse(arr)
    print(arr)
    reverse(arr)
    print(arr)

    print('\n# rotate example 1')
    source = [_ for _ in range(-20, 20, 7)]
    arr = StaticArray(len(source))
    for i, value in enumerate(source):
        arr.set(i, value)
    print(arr)
    for steps in [1, 2, 0, -1, -2, 28, -100, 2 ** 28, -2 ** 31]:
        space = " " if steps >= 0 else ""
        print(f"{rotate(arr, steps)} {space}{steps}")
    print(arr)

    print('\n# rotate example 2')
    array_size = 1_000_000
    source = [random.randint(-10 ** 9, 10 ** 9) for _ in range(array_size)]
    arr = StaticArray(len(source))
    for i, value in enumerate(source):
        arr[i] = value
    print(f'Started rotating large array of {array_size} elements')
    rotate(arr, 3 ** 14)
    rotate(arr, -3 ** 15)
    print(f'Finished rotating large array of {array_size} elements')

    print('\n# sa_range example 1')
    cases = [
        (1, 3), (-1, 2), (0, 0), (0, -3),
        (-95, -89), (-89, -95)]
    for start, end in cases:
        print(f"Start: {start: 4}, End: {end: 4}, {sa_range(start, end)}")

    print('\n# is_sorted example 1')
    test_cases = (
        [-100, -8, 0, 2, 3, 10, 20, 100],
        ['A', 'B', 'Z', 'a', 'z'],
        ['Z', 'T', 'K', 'A', '5'],
        [1, 3, -10, 20, -30, 0],
        [-10, 0, 0, 10, 20, 30],
        [100, 90, 0, -90, -200],
        ['apple']
    )
    for case in test_cases:
        arr = StaticArray(len(case))
        for i, value in enumerate(case):
            arr[i] = value
        result = is_sorted(arr)
        space = "  " if result is not None and result >= 0 else " "
        print(f"Result:{space}{result}, {arr}")

    print('\n# find_mode example 1')
    test_cases = (
        [1, 20, 30, 40, 500, 500, 500],
        [2, 2, 2, 2, 1, 1, 1, 1],
        ["zebra", "sloth", "otter", "otter", "moose", "koala"],
        ["Albania", "Belgium", "Chile", "Denmark", "Egypt", "Fiji"]
    )
    for case in test_cases:
        arr = StaticArray(len(case))
        for i, value in enumerate(case):
            arr[i] = value

        result = find_mode(arr)
        if result:
            print(f"{arr}\nMode: {result[0]}, Frequency: {result[1]}\n")
        else:
            print("find_mode() not yet implemented\n")

    print('# remove_duplicates example 1')
    test_cases = (
        [1], [1, 2], [1, 1, 2], [1, 20, 30, 40, 500, 500, 500],
        [5, 5, 5, 4, 4, 3, 2, 1, 1], [1, 1, 1, 1, 2, 2, 2, 2]
    )
    for case in test_cases:
        arr = StaticArray(len(case))
        for i, value in enumerate(case):
            arr[i] = value
        print(arr)
        print(remove_duplicates(arr))
    print(arr)

    print('\n# count_sort example 1')
    test_cases = (
        [1, 2, 4, 3, 5], [5, 4, 3, 2, 1], [0, -5, -3, -4, -2, -1, 0],
        [-3, -2, -1, 0, 1, 2, 3], [1, 2, 3, 4, 3, 2, 1, 5, 5, 2, 3, 1],
        [10100, 10721, 10320, 10998], [-100320, -100450, -100999, -100001],
    )
    for case in test_cases:
        arr = StaticArray(len(case))
        for i, value in enumerate(case):
            arr[i] = value
        print(f"Before: {arr}")
        result = count_sort(arr)
        print(f"After : {result}")

    print('\n# count_sort example 2')
    array_size = 5_000_000
    min_val = random.randint(-10 ** 9, 10 ** 9 - 998)
    max_val = min_val + 998
    case = [random.randint(min_val, max_val) for _ in range(array_size)]
    arr = StaticArray(len(case))
    for i, value in enumerate(case):
        arr[i] = value
    print(f'Started sorting large array of {array_size} elements')
    result = count_sort(arr)
    print(f'Finished sorting large array of {array_size} elements')

    print('\n# sorted_squares example 1')
    test_cases = (
        [1, 2, 3, 4, 5],
        [-5, -4, -3, -2, -1, 0],
        [-3, -2, -2, 0, 1, 2, 3],
    )
    for case in test_cases:
        arr = StaticArray(len(case))
        for i, value in enumerate(sorted(case)):
            arr[i] = value
        print(arr)
        result = sorted_squares(arr)
        print(result)

    print('\n# sorted_squares example 2')
    array_size = 5_000_000
    case = [random.randint(-10 ** 9, 10 ** 9) for _ in range(array_size)]
    arr = StaticArray(len(case))
    for i, value in enumerate(sorted(case)):
        arr[i] = value
    print(f'Started sorting large array of {array_size} elements')
    result = sorted_squares(arr)
    print(f'Finished sorting large array of {array_size} elements')
